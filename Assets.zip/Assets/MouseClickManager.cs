﻿using UnityEngine;

public class MouseClickManager : MonoBehaviour
{
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit[] hits = Physics.RaycastAll(ray, 1000f);

            foreach (RaycastHit hit in hits)
            {
                Debug.Log("ضرب: " + hit.collider.gameObject.name);
                Debug.Log("بيرنت: " + hit.collider.transform.root.gameObject.name);

                var dropper = hit.collider.GetComponentInParent<DropperSequence>()
                              ?? hit.collider.GetComponent<DropperSequence>();
                if (dropper != null)
                {
                    dropper.HandleClick();
                    return;
                }

                var spoon = hit.collider.GetComponentInParent<SpoonAction>()
                            ?? hit.collider.GetComponent<SpoonAction>();
                if (spoon != null)
                {
                    spoon.HandleClick();
                    return;
                }
            }
        }
    }
}