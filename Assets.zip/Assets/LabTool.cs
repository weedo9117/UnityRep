﻿using UnityEngine;

public class LabTool : MonoBehaviour
{
    [Header("Setup")]
    public Transform holdPoint;
    public GameObject contentInside; // البودرة أو السائل اللي جوه الأداة
    public ParticleSystem actionEffect; // الدخان أو التأثير اللي بيحصل بره

    private Rigidbody rb;
    private bool isHeld = false;
    private bool hasContent = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (contentInside) contentInside.SetActive(false);
    }

    void Update()
    {
        if (isHeld)
        {
            FollowHand();
            if (Input.GetMouseButtonDown(0)) ExecuteAction();
        }
    }

    void OnMouseDown()
    {
        if (!isHeld) PickUp();
        else Drop();
    }

    void PickUp()
    {
        isHeld = true;
        rb.isKinematic = true;
        transform.SetParent(holdPoint);
    }

    void FollowHand()
    {
        transform.position = holdPoint.position;
        transform.rotation = holdPoint.rotation;
    }

    void Drop()
    {
        isHeld = false;
        transform.SetParent(null);
        rb.isKinematic = false;
        rb.useGravity = true;
    }

    void ExecuteAction()
    {
        if (!hasContent)
        {
            hasContent = true;
            if (contentInside) contentInside.SetActive(true);
            Debug.Log("تم سحب المادة");
        }
        else
        {
            hasContent = false;
            if (contentInside) contentInside.SetActive(false);
            if (actionEffect) actionEffect.Play();
            Debug.Log("تم صب المادة");
        }
    }
}